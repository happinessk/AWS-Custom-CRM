<?php

namespace App;


use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Emails extends Model
{
    public static function subscribe($data)
    {

        try {
            DB::insert('insert into ebdb.emails select ?,?,NOW(),0', [$data['email_address'],'subscribe']);



            return ['success' => 'You have successfully subscribed! Please expect an email soon.'];
        } catch (Exception $e) {


            return ['success' => 'There was an error subscribing. Please try again.'];
        }
    }

    public static function unsubscribe($data)
    {

        try {
            DB::insert('insert into ebdb.emails select ?,?,NOW(),0', [$data['email_address'],'unsubscribe']);



            return ['success'=>'You have unsubscribed from everything. We\'re sorry to see you go.'];
        } catch (Exception $e) {


            return ['success' => 'There was an error unsubscribing. Please try again.'];
        }
    }
}
