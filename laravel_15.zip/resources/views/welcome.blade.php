<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>RESG176 - Group C - Assignment 2</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="flex-center position-ref full-height">
        @if (Route::has('login'))
        <div class="top-right links">
            @auth
            <a href="{{ url('/home') }}">Home</a>
            @else
            <a href="{{ route('login') }}">Login</a>

            @if (Route::has('register'))
            <a href="{{ route('register') }}">Register</a>
            @endif
            @endauth
        </div>
        @endif

        <div class="content">
            <div class="title m-b-md">
                Thanks for your interest!
            </div>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="inp_email" placeholder="Your email address" aria-label="Your email address" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" id="btn_subscribe" type="button">Subscribe</button>
                </div>
                <div id="invalid_email" class="invalid-feedback" style="display:none">
                    Please provide a valid email address.
                </div>
            </div>
            <br>
            <br>
            <br>
            <br>
            <div class="links">
                <button class="btn btn-outline-secondary btn-sm" id="btn_unsubscribe" type="button">Unsubscribe</button>

            </div>
        </div>
    </div>
</body>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $("#btn_subscribe").click(function() {
        let email_address = $('#inp_email').val();
        if (!validateEmail(email_address) || isEmpty(email_address)) {
            $('#invalid_email').show();
            return;

        }
        $('#invalid_email').hide();
        $.ajax({
            type: 'POST',
            url: "{{ route('subscribe.post') }}",
            data: {
                email_address: email_address
            },
            success: function(data) {
                alert(data.success);
            }
        });
    });


    $("#btn_unsubscribe").click(function() {
        let email_address = $('#inp_email').val();
        if (!validateEmail(email_address) || isEmpty(email_address)) {
            $('#invalid_email').show();
            return;

        }

        $.ajax({
            type: 'POST',
            url: "{{ route('unsubscribe.post') }}",
            data: {
                email_address: email_address
            },
            success: function(data) {
                alert(data.success);
            }
        });
    });

    function validateEmail(email) {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        return emailReg.test(email);
    }

    function isEmpty(email) {
        return !email.trim().length;
    }
</script>

</html>